﻿using Task02MVC.Models;

namespace Task02MVC.ViewModels
{
    public class StudentIndexViewModel
    {
        // الداتا
        public List<Student> Students { get; set; } = new List<Student>();
        public List<Department> Departments { get; set; } = new List<Department>();

        // Search + Filter (القيم الحالية)
        public string? Search { get; set; }
        public int? DeptId { get; set; }

        // Pagination
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }

        // Properties محسوبة
        public int TotalPages => (int)Math.Ceiling((double)TotalCount / PageSize);
        public bool HasPrevious => Page > 1;
        public bool HasNext => Page < TotalPages;
    }
}
