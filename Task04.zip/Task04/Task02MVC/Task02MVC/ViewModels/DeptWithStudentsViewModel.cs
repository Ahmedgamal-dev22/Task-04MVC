﻿namespace Task02MVC.ViewModels
{
    public class DeptWithStudentsViewModel
    {
        public string DeptName { get; set; } = null!;
        public List<string> StudentNames { get; set; } = new List<string>();
        public string DeptState { get; set; } = null!;
    }
}
