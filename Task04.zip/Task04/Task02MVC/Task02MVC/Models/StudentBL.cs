﻿using Microsoft.EntityFrameworkCore;
using Task02MVC.Data.DbContexts;
using Task02MVC.Models;

namespace Task02MVC.Models
{
    public class StudentBL
    {
        // Open connection with DB
        SchoolDbContext context = new SchoolDbContext();

        // GetAll: Search + Filter + Pagination
        public List<Student> GetAll(string? search, int? deptId, int page, int pageSize, out int totalCount)
        {
            IQueryable<Student> query = context.Students.Include(S => S.Department);

            // Search by name
            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(S => S.Name.Contains(search));

            // Filter by department
            if (deptId.HasValue)
                query = query.Where(S => S.DepartmentId == deptId.Value);

            // العدد الكلي بعد الـ Search والـ Filter (قبل الـ Pagination)
            totalCount = query.Count();

            // Pagination
            return query
                .OrderBy(S => S.Id)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();
        }

        // GetById (ومعاه الـ Department)
        public Student? GetById(int id)
        {
            return context.Students
                .Include(S => S.Department)
                .FirstOrDefault(S => S.Id == id);
        }

        // Add
        public void Add(Student student)
        {
            context.Students.Add(student);   // Local
            context.SaveChanges();           // INSERT
        }

        // Edit: الأوبجكت المتعدل متتبَّع، فكفاية SaveChanges
        public void SaveInDB()
        {
            context.SaveChanges();           // UPDATE
        }

        // Delete
        public void Delete(Student student)
        {
            context.Students.Remove(student);   // Local
            context.SaveChanges();              // DELETE
        }
    }
}