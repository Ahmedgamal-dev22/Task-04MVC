﻿using Microsoft.AspNetCore.Mvc;
using Task02MVC.Models;
using Task02MVC.ViewModels;


namespace Task02MVC.Controllers
{
    public class DepartmentController : Controller
    {
        DepartmentBL departmentBL = new DepartmentBL();

        // Req URL: /Department/ShowAll
        public IActionResult ShowAll()
        {
            List<Department> depts = departmentBL.GetAll();
            return View("ShowAll", depts);
        }

        // Req URL: /Department/ShowDetails?id=1
        public IActionResult ShowDetails(int id)
        {
            Department? dept = departmentBL.GetById(id);

            if (dept == null)
                return NotFound();

            return View("ShowDetails", dept);
        }

        // Req URL: /Department/Add  (GET: يعرض الفورم الفاضية)
        [HttpGet]
        public IActionResult Add()
        {
            return View("Add");
        }

        // Req URL: /Department/SaveAdd  (POST: يستقبل الداتا ويحفظها)
        [HttpPost]
        public IActionResult SaveAdd(Department DeptSent)
        {
            if (!string.IsNullOrWhiteSpace(DeptSent.Name))
            {
                departmentBL.AddDept(DeptSent);
                return RedirectToAction(nameof(ShowAll));   // Request جديد
            }

            return View("Add", DeptSent);   // رجّع الفورم بالداتا
        }


        // Req URL: /Department/ShowDetailsVM?id=1
        public IActionResult ShowDetailsVM(int id)
        {
            // 1) Resources: جيب الداتا من الـ BL
            Department? dept = departmentBL.GetById(id);

            if (dept == null)
                return NotFound();

            // 2) Mapping: انقل الداتا للـ ViewModel
            DeptWithStudentsViewModel VM = new DeptWithStudentsViewModel();
            VM.DeptName = dept.Name;

            VM.StudentNames = dept.Students?
                .Where(S => S.Age > 25)
                .Select(S => S.Name)
                .ToList() ?? new List<string>();

            int studentsCount = dept.Students?.Count ?? 0;
            VM.DeptState = studentsCount > 50 ? "Main" : "Branch";

            // 3) ابعته للـ View
            return View("ShowDetailsVM", VM);
        }
    }
}
