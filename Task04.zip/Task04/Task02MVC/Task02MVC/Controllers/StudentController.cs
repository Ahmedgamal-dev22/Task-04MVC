﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Task02MVC.Models;
using Task02MVC.ViewModels;


namespace Task02MVC.Controllers
{
    public class StudentController : Controller
    {
        StudentBL studentBL = new StudentBL();
        DepartmentBL departmentBL = new DepartmentBL();

        // ============ GetAll ============
        // /Student/GetAll?search=ali&deptId=1&page=2
        public IActionResult GetAll(string? search, int? deptId, int page = 1)
        {
            int pageSize = 5;
            if (page < 1) page = 1;

            // Sources
            List<Student> students = studentBL.GetAll(search, deptId, page, pageSize, out int totalCount);

            // Destination + Mapping
            StudentIndexViewModel VM = new StudentIndexViewModel();
            VM.Students = students;
            VM.Departments = departmentBL.GetAll();
            VM.Search = search;
            VM.DeptId = deptId;
            VM.Page = page;
            VM.PageSize = pageSize;
            VM.TotalCount = totalCount;

            return View("GetAll", VM);
        }

        // ============ GetById ============
        // /Student/GetById?id=3
        public IActionResult GetById(int id)
        {
            Student? student = studentBL.GetById(id);
            if (student == null)
                return NotFound();

            return View("GetById", student);
        }

        // ============ Add ============
        // GET: /Student/Add
        [HttpGet]
        public IActionResult Add()
        {
            StudentFormViewModel VM = new StudentFormViewModel();
            VM.DeptList = departmentBL.GetAll();
            return View("Add", VM);
        }

        // POST: /Student/SaveAdd
        [HttpPost]
        public IActionResult SaveAdd(StudentFormViewModel vm)
        {
            if (ModelState.IsValid)
            {
                // Mapping: ViewModel -> Model
                Student student = new Student();
                student.Name = vm.Name;
                student.Age = vm.Age;
                student.DepartmentId = vm.DepartmentId!.Value;

                studentBL.Add(student);
                return RedirectToAction(nameof(GetAll));
            }

            vm.DeptList = departmentBL.GetAll();   // نملّى الـ Dropdown تاني
            return View("Add", vm);
        }

        // ============ Edit ============
        // GET: /Student/Edit/3
        [HttpGet]
        public IActionResult Edit(int id)
        {
            Student? student = studentBL.GetById(id);
            if (student == null)
                return NotFound();

            // Mapping: Model -> ViewModel
            StudentFormViewModel VM = new StudentFormViewModel();
            VM.Id = student.Id;
            VM.Name = student.Name;
            VM.Age = student.Age;
            VM.DepartmentId = student.DepartmentId;
            VM.DeptList = departmentBL.GetAll();

            return View("Edit", VM);
        }

        // POST: /Student/SaveEdit
        [HttpPost]
        public IActionResult SaveEdit(StudentFormViewModel vm)
        {
            if (ModelState.IsValid)
            {
                Student? oldStudent = studentBL.GetById(vm.Id);
                if (oldStudent == null)
                    return NotFound();

                // Update الأصل المتتبَّع
                oldStudent.Name = vm.Name;
                oldStudent.Age = vm.Age;
                oldStudent.DepartmentId = vm.DepartmentId!.Value;

                studentBL.SaveInDB();
                return RedirectToAction(nameof(GetAll));
            }

            vm.DeptList = departmentBL.GetAll();
            return View("Edit", vm);
        }

        // ============ Delete ============
        // GET: /Student/Delete/3  (صفحة التحذير)
        [HttpGet]
        public IActionResult Delete(int id)
        {
            Student? student = studentBL.GetById(id);
            if (student == null)
                return NotFound();

            return View("Delete", student);
        }

        // POST: /Student/ConfirmDelete/3
        [HttpPost]
        public IActionResult ConfirmDelete(int id)
        {
            Student? student = studentBL.GetById(id);
            if (student == null)
                return NotFound();

            try
            {
                studentBL.Delete(student);
                return RedirectToAction(nameof(GetAll));
            }
            catch (DbUpdateException)
            {
                // الطالب عنده درجات في StuCrsRes (FK بـ Restrict)
                ViewBag.Error = "Can't delete this student because he has course results.";
                return View("Delete", student);
            }
        }
    }
}