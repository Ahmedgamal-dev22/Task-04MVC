﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Task02MVC.Models;

namespace Task02MVC.Data.NewFolder
{
    public class TeacherConfigurations : IEntityTypeConfiguration<Teacher>
    {
        public void Configure(EntityTypeBuilder<Teacher> builder)
        {
            builder.ToTable("Teachers");

            builder.HasKey(T => T.Id);

            builder.Property(T => T.Name).HasMaxLength(100);
            builder.Property(T => T.Address).HasMaxLength(100);
            builder.Property(T => T.Salary).HasPrecision(18, 2);

            // Teacher -> Department
            builder.HasOne(T => T.Department)
                   .WithMany(D => D.Teachers)
                   .HasForeignKey(T => T.DepartmentId)
                   .OnDelete(DeleteBehavior.Restrict);

            // Teacher -> Course
            builder.HasOne(T => T.Course)
                   .WithMany(C => C.Teachers)
                   .HasForeignKey(T => T.CourseId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
