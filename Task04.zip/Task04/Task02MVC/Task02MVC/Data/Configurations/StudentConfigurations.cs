﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Task02MVC.Models;

namespace Task02MVC.Data.NewFolder
{
    public class StudentConfigurations : IEntityTypeConfiguration<Student>
    {
        public void Configure(EntityTypeBuilder<Student> builder)
        {
            builder.ToTable("Students");

            builder.HasKey(S => S.Id);

            builder.Property(S => S.Name).HasMaxLength(100);

            builder.HasOne(S => S.Department)
                   .WithMany(D => D.Students)
                   .HasForeignKey(S => S.DepartmentId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
