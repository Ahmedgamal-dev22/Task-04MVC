﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Task02MVC.Models;

namespace Task02MVC.Data.NewFolder
{
    public class CourseConfigurations : IEntityTypeConfiguration<Course>
    {
        public void Configure(EntityTypeBuilder<Course> builder)
        {
            builder.ToTable("Courses");

            builder.HasKey(C => C.Id);

            builder.Property(C => C.Name).HasMaxLength(50);

            builder.HasOne(C => C.Department)
                   .WithMany(D => D.Courses)
                   .HasForeignKey(C => C.DepartmentId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
